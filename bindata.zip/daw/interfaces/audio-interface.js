//
// DAW IAudio
// (c) Thor Muto Asmund, 2018
//

export class IAudio {
  getValue(t) { }
}