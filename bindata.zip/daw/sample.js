//
// DAW Sample
// (c) Thor Muto Asmund, 2018
//

export class Sample {
  constructor(options = {}) {
    if (options.fileName) {
      this.loadFromFile(options);
    }
    else {
      this.initBlank(options);
    }
  }

  static create(options) {
    const sample = new Sample(options);
    return sample;
  }

  loadFromFile(options) {
    this.channels = 2;
    this.size = 0;

    this.buffers = new Array(this.channels);
    for (var c = 0; c < this.channels; ++c) {
      this.buffers[c] = new Float32Array(this.size);    
    }
    this.clear();
  }

  initBlank(options) {
    this.channels = options.channels | 2;
    if (this.channels < 1 || this.channels > 2) {
      throw 'Invalid number of channels';
    }
    this.size = options.size | 0;
    if (this.size < 0) {
      throw 'Invalid track size';
    }
    
    this.buffers = new Array(this.channels);
    for (var c = 0; c < this.channels; ++c) {
      this.buffers[c] = new Float32Array(this.size);    
    }
    this.clear();    
  }

  clear() {
    this.buffers.forEach(buffer => buffer.fill(0));
  }

  getValue(t) {
    return 0.0;
  }

  set(channel, index, value) {
    if (index < 0 || index >= this.size) {
      throw 'Index out of bounds';
    }
    if (channel < 0 || channel >= this.channels) {
      throw 'Channel out of bounds';
    }
    this.buffers[channel][index] = value;
  }

  get(channel, index) {
    if (index < 0 || index >= this.size) {
      throw 'Index out of bounds';
    }
    if (channel < 0 || channel >= this.channels) {
      throw 'Channel out of bounds';
    }
    return this.buffers[channel][index];    
  }
}